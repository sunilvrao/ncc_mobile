### Description
Add a detailed description of your issue.

### Repro Steps
Layout the steps to reproduce your issue.

Use this Codepen to demonstrate your issue. http://codepen.io/Dogfalo/pen/xbzPQV

### Screenshots / Codepen
Add supplemental screenshots or code examples. Look for a codepen template in our Contributing Guidelines.
